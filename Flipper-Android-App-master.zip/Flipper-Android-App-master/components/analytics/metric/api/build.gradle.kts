plugins {
    id("flipper.android-lib")
}

android.namespace = "com.flipperdevices.metric.api"

dependencies {
}
