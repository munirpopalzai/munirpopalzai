plugins {
    id("flipper.android-lib")
}

android.namespace = "com.flipperdevices.core.permission.api"

dependencies {
}
