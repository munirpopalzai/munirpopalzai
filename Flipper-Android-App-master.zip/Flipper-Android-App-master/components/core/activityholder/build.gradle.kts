plugins {
    id("flipper.android-lib")
}

android.namespace = "com.flipperdevices.core.activityholder"

dependencies {
    implementation(libs.appcompat)
}
