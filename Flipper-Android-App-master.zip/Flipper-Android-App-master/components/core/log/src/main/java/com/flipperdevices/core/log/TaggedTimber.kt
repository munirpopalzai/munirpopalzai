package com.flipperdevices.core.log

class TaggedTimber(override val TAG: String) : LogTagProvider
