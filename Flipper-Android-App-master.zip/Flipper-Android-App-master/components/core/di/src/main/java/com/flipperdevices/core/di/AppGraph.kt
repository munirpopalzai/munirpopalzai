package com.flipperdevices.core.di

abstract class AppGraph private constructor()
