package com.flipperdevices.bottombar.handlers

interface ResetTabDecomposeHandler {
    fun onResetTab()
}
