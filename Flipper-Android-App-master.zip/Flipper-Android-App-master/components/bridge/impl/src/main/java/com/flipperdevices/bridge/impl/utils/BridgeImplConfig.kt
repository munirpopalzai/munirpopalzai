package com.flipperdevices.bridge.impl.utils

object BridgeImplConfig {
    const val BLE_VLOG = false
}
