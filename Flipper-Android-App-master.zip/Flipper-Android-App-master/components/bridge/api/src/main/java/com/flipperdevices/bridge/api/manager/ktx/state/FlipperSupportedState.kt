package com.flipperdevices.bridge.api.manager.ktx.state

enum class FlipperSupportedState {
    DEPRECATED_FLIPPER,
    DEPRECATED_APPLICATION,
    READY
}
