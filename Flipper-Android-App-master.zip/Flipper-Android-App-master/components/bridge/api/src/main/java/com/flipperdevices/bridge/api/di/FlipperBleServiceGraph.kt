package com.flipperdevices.bridge.api.di

abstract class FlipperBleServiceGraph private constructor()
