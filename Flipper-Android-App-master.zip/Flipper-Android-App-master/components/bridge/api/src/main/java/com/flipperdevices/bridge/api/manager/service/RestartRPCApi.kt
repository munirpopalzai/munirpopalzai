package com.flipperdevices.bridge.api.manager.service

interface RestartRPCApi {
    suspend fun restartRpc()
}
