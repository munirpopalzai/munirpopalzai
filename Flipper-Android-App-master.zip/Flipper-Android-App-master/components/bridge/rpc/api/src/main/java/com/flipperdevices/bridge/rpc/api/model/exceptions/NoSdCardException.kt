package com.flipperdevices.bridge.rpc.api.model.exceptions

class NoSdCardException : RuntimeException()
