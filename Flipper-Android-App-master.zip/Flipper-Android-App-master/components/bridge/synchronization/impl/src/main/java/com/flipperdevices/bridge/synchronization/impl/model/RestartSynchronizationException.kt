package com.flipperdevices.bridge.synchronization.impl.model

/**
 * If we catch this exception, we restart synchronization
 */
class RestartSynchronizationException : RuntimeException()
