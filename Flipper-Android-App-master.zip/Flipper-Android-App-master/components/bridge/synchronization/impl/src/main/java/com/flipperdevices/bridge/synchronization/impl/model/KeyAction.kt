package com.flipperdevices.bridge.synchronization.impl.model

/**
 * Order is important!
 */
enum class KeyAction {
    DELETED,
    ADD,
    MODIFIED
}
