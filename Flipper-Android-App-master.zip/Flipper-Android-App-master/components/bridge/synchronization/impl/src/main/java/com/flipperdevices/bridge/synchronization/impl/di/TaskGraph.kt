package com.flipperdevices.bridge.synchronization.impl.di

abstract class TaskGraph private constructor()
