package com.flipperdevices.bridge.synchronization.ui.model

internal enum class ItemSynchronizationState {
    SYNCHRONIZED,
    IN_PROGRESS,
    NOT_SYNCHRONIZED
}
