package com.flipperdevices.bridge.protobuf

object ProtobufConstants {
    const val MAX_FILE_DATA = 512
}
