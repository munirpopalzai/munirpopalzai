package com.flipperdevices.bridge.dao.api.model

typealias FapHubHiddenItem = String
