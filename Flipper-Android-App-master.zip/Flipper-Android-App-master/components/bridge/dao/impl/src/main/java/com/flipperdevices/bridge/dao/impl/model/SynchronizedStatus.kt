package com.flipperdevices.bridge.dao.impl.model

enum class SynchronizedStatus {
    NOT_SYNCHRONIZED,
    SYNCHRONIZED
}
