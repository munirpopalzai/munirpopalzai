package com.flipperdevices.bridge.dao.impl.model

import com.flipperdevices.bridge.dao.api.model.FlipperKeyContent

data class DatabaseKeyContent(
    val flipperContent: FlipperKeyContent
)
