package com.flipperdevices.bridge.rpcinfo.impl.mapper

internal data class InternalFlipperRpcInformationRaw(
    val otherFields: Map<String, String> = emptyMap()
)
