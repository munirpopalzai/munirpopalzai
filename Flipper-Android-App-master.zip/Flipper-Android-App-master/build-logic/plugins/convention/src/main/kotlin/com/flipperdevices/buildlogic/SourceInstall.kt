package com.flipperdevices.buildlogic

enum class SourceInstall {
    GITHUB,
    GOOGLE_PLAY,
    UNKNOWN,
    DEBUG
}
